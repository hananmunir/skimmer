export const colors = [
  "green",
  "blue",
  "indigo",
  "violet",
  "magenta",
  "teal",
  "lime",
  "olive",
  "navy",
  "maroon",
];


